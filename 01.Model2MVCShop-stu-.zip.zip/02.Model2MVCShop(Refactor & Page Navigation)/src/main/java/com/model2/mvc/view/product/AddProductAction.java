package com.model2.mvc.view.product;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.model2.mvc.framework.Action;
import com.model2.mvc.service.domain.Product;
import com.model2.mvc.service.product.ProductService;
import com.model2.mvc.service.product.impl.ProductServiceImpl;
import com.model2.mvc.service.domain.Purchase;
 


public class AddProductAction extends Action {

	@Override
	public String execute(	HttpServletRequest request,
												HttpServletResponse response) throws Exception {
		Product product = new Product();
		Purchase purchase = new Purchase();
		HttpSession session = request.getSession();
		
		System.out.println("�׽�Ʈ"+request.getParameter("price"));
		System.out.println(request.getParameter("prodName"));
		System.out.println(request.getParameter("prodDetail"));
		
		purchase.setTranCode("tranCode");
		product.setProdName(request.getParameter("prodName"));
		product.setProdDetail(request.getParameter("prodDetail"));
	 	product.setManuDate((request.getParameter("manuDate")).replaceAll("-", "")); 
		product.setPrice(Integer.parseInt(request.getParameter("price")));
		product.setFileName(request.getParameter("fileName"));
		
		
		System.out.println(product);
		
		ProductService service= new ProductServiceImpl();
		service.addProduct(product);
		session.setAttribute("product", product);
		
		return "redirect:/product/addProduct.jsp";
	}

 
}